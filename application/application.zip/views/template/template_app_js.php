<!-- App js -->
<script src="<?= base_url('assets/'); ?>plugins/jquery-loader/jquery.loading.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>

<!-- Toastr Js -->
<script src="<?= base_url('assets/'); ?>plugins/toastr/toastr.min.js"></script>

<!-- Sweet Alert Js  -->
<script src="<?= base_url('assets/'); ?>plugins/sweet-alert/sweetalert2.all.min.js"></script>
<!-- <script src="<?= base_url('assets/'); ?>plugins/currency/currency.js"></script> -->
<script src="<?= base_url('assets/'); ?>js/jquery.core.js"></script>
<script src="<?= base_url('assets/'); ?>js/jquery.app.js"></script>
<script src="<?= base_url('assets/'); ?>js/logout.js"></script>


</body>

</html>