    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    Copyright 24codes.my.id
                </div>
            </div>
        </div>
    </footer>
    <!-- End Footer -->