<div class="wrapper-page">
    <div class="ex-page-content text-center">
        <div class="text-error">404</div>
        <h3 class="text-uppercase font-600">Page not Found</h3>
        <p class="text-muted">
            Sepertinya halaman yang dicari tidak ada!.
        </p>
        <br>
        <a class="btn btn-success waves-effect waves-light" href="<?= base_url('dashboard/'); ?>"> Kembali</a>

    </div>
</div>