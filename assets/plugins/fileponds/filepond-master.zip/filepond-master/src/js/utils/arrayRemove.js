export const arrayRemove = (arr, index) => arr.splice(index, 1);
