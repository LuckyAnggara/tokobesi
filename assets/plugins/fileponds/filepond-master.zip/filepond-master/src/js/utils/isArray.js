export const isArray = value => Array.isArray(value);
