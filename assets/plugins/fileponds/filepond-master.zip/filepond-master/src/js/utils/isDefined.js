export const isDefined = value => value != null;
