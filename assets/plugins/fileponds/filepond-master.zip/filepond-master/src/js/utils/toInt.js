import { toNumber } from './toNumber';
export const toInt = value => parseInt(toNumber(value), 10);
