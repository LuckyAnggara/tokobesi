export const getNonNumeric = str => /[^0-9]+/.exec(str);
