<script src="<?= base_url('assets/'); ?>plugins/jquery-knob/jquery.knob.js"></script>

<!--Morris Chart-->
<script src="<?= base_url('assets/'); ?>plugins/morris/morris.min.js"></script>
<script src="<?= base_url('assets/'); ?>plugins/raphael/raphael-min.js"></script>

<!-- Dashboard init -->
<script src="<?= base_url('assets/'); ?>pages/jquery.dashboard.js"></script>