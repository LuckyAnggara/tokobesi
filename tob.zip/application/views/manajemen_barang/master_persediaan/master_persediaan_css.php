<!-- DataTables -->
<link href="<?= base_url('assets/');?>plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url('assets/');?>plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />