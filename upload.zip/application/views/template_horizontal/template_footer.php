    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    2016 - 2018 © Adminto. Coderthemes.com
                </div>
            </div>
        </div>
    </footer>
    <!-- End Footer -->



