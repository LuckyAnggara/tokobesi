<!-- shake effect css -->
<link href="<?= base_url('assets/'); ?>plugins/jquery-ui/jquery-ui.min.css" rel="stylesheet" type="text/css">


<!-- DataTables -->
<link href="<?= base_url('assets/'); ?>plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />

<!-- Sweet Alert css -->
<link href="<?= base_url('assets/'); ?>plugins/sweet-alert/sweetalert2.min.css" rel="stylesheet" type="text/css" />


<!-- datepicker -->
<link href="<?= base_url('assets/'); ?>plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
<link href="<?= base_url('assets/'); ?>plugins/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">