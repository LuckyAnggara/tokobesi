<?php
class pdf {
    function __construct() {
        include_once APPPATH . 'libraries/vendor/fpdf/fpdf.php';
    }
}
?>