  <!-- X-editable css -->
  <link type="text/css"
  	href="<?= base_url('assets/'); ?>plugins/x-editable/dist/bootstrap3-editable/css/bootstrap-editable.css"
  	rel="stylesheet">
  <!-- form Uploads -->
  <link href="<?= base_url('assets/'); ?>plugins/fileuploads/css/dropify.min.css" rel="stylesheet" type="text/css" />

  <!-- datepicker -->
  <link href="<?= base_url('assets/'); ?>plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css"
  	rel="stylesheet">
  <link href="<?= base_url('assets/'); ?>plugins/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
