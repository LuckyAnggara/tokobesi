<!-- App js -->
<script src="<?= base_url('assets/'); ?>plugins/jquery-loader/jquery.loading.js"></script>
<script src="<?= base_url('assets/'); ?>js/loading.js"></script>

<!-- Toastr Js -->
<script src="<?= base_url('assets/'); ?>plugins/toastr/toastr.min.js"></script>

<!-- Sweet Alert Js  -->
<script src="<?= base_url('assets/'); ?>plugins/sweet-alert/sweetalert2.all.min.js"></script>
<!-- <script src="<?= base_url('assets/'); ?>plugins/currency/currency.js"></script> -->
<script src="<?= base_url('assets/'); ?>js/jquery.core.js"></script>
<script src="<?= base_url('assets/'); ?>js/jquery.app.js"></script>

</body>

</html>