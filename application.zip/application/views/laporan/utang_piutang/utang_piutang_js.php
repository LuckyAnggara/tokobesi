<script src="<?= base_url('assets/'); ?>plugins/bootstrap-inputmask/bootstrap-inputmask.min.js" type="text/javascript"></script>
<!-- Validation js (Parsleyjs) -->
<script type="text/javascript" src="<?= base_url('assets/'); ?>plugins/parsleyjs/dist/parsley.min.js"></script>

<!-- Required datatable js -->
<script src="<?= base_url('assets/'); ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url('assets/'); ?>plugins/datatables/dataTables.bootstrap4.min.js"></script>
<!-- Buttons examples -->
<script src="<?= base_url('assets/'); ?>plugins/datatables/dataTables.buttons.min.js"></script>
<script src="<?= base_url('assets/'); ?>plugins/datatables/buttons.bootstrap4.min.js"></script>
<script src="<?= base_url('assets/'); ?>plugins/datatables/jszip.min.js"></script>
<script src="<?= base_url('assets/'); ?>plugins/datatables/pdfmake.min.js"></script>
<script src="<?= base_url('assets/'); ?>plugins/datatables/vfs_fonts.js"></script>
<script src="<?= base_url('assets/'); ?>plugins/datatables/buttons.html5.min.js"></script>
<script src="<?= base_url('assets/'); ?>plugins/datatables/buttons.print.min.js"></script>

<!-- DatePicker Js -->
<script src="<?= base_url('assets/'); ?>plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>

<!-- Select2 js -->
<script src="<?= base_url('assets/'); ?>plugins/select2/js/select2.min.js" type="text/javascript"></script>
<!-- Input Mask Js dan Max Length-->
<script src="<?= base_url('assets/'); ?>plugins/bootstrap-inputmask/bootstrap-inputmask.min.js" type="text/javascript"></script>
<script src="<?= base_url('assets/'); ?>plugins/bootstrap-maxlength/bootstrap-maxlength.min.js" type="text/javascript"></script>




<!-- script init -->
<script type="text/javascript">
    $(document).ready(function() {
        $('#tanggal_utang').datepicker({
            autoclose: true,
            todayHighlight: true,
            orientation: 'auto'
        });
        $('#tanggal_piutang').datepicker({
            autoclose: true,
            todayHighlight: true,
            orientation: 'auto'
        });
    });

    // $('#utang_form').submit(function(e) {
    //     e.preventDefault();
    //     var data = new FormData(document.getElementById("utang_form"));
    //     $.ajax({
    //         // url: '<?= base_url("laporan/utangpiutang/laporan_utang/"); ?>',
    //         // type: "post",
    //         data: data,
    //         // async:false,
    //         // processData: false,
    //         // contentType: false,
    //         beforeSend: function() {
    //             $.LoadingOverlay("show");
    //         },
    //         complete: function(data) {
    //             $.LoadingOverlay("hide");
    //         },
    //         // success: function(data) {
    //         //     window.open(this.url, '_blank');
    //         // }
    //     })
    // })
</script>