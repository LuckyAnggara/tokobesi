<link href="<?= base_url('assets/'); ?>plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
<link href="<?= base_url('assets/'); ?>plugins/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
