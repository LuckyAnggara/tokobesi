    <!-- Footer -->
    <footer class="footer">
        <div class="row">
            <div class="col-3 text-left">
                <span>
                    Powered By 24codes
                </span>
            </div>
            <div class="col-6 text-left">
            </div>
            <div class="col-3 text-right">
                <span>
                    Application Version 1.0.0
                </span>
            </div>
        </div>
    </footer>
    <!-- End Footer -->