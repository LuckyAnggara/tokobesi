<div class="wrapper-page">
    <div class="ex-page-content text-center">
        <div class="text-error">Oopss</div>
        <h3 class="text-uppercase font-600">Toko belum di Buka</h3>
        <p class="text-muted">
            Silahkan buka Toko terlebih dahulu.
        </p>
        <br>
        <a class="btn btn-success waves-effect waves-light" href="<?= base_url('dashboard/'); ?>"> Kembali</a>

    </div>
</div>