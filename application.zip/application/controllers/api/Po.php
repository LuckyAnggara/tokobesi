<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Po extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
    }
        public function get_data_cabang()
        {
            // $string = $this->input->post('query');
            $this->db->select('*');
            $this->db->from('master_cabang');
            // $this->db->like('nama_cabang', $string);
            $data =  $this->db->get()->result_array();

            $output = json_encode($data);
            echo $output;
        }

    public function receive()
    {
        $post = $this->input->post();
        $data = [
            'dari' => $post['kode_perusahaan'],
            'no_order_po' => $post['kode_perusahaan']. '-'.$post['no_order_po'],
            'total_pembelian' => $post['total_pembelian'],
            'biaya_lainnya' => $post['biaya_lainnya'],
            'grand_total' => $post['grand_total'],
            'keterangan' => $post['keterangan'],
            'status' => 0,
            'tanggal_masuk' => date('Y-m-d H:i:s'),
        ];
        $this->db->insert('master_receive_po', $data);

        echo 'sukses';
    }
}
   