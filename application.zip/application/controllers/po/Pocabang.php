<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pocabang extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->helper('string');
        $this->load->model('Manajemen_Penjualan/Model_Penjualan_Barang', 'modelPenjualan');
        $this->load->model('Po/Model_Po', 'modelPO');
        $this->load->model('Setting/Model_Setting', 'modelSetting');

        if ($this->session->userdata('status') != "login") {
            redirect(base_url("login"));
        }
    }

    public function tambah_data()
    {
        if ($this->session->userdata('role') !== "2") {
            redirect(base_url("dashboard"));
        } else {
            $data['menu'] = $this->modelSetting->data_menu();
            $data['setting_perusahaan'] = $this->modelSetting->get_data_perusahaan();
            $data['no_order_po'] = $this->_generateNomor();
            $data['css'] = 'po/tambah_data/po_css';
            $this->load->view('template/template_header', $data);
            $this->load->view('template/template_menu');
            $this->load->view('po/tambah_data/po', $data);
            $this->load->view('template/template_right');
            $this->load->view('po/tambah_data/po_modal', $data);
            $this->load->view('template/template_footer');
            $this->load->view('template/template_js');
            $this->load->view('po/tambah_data/po_js');
            $this->load->view('template/template_app_js');
        }
    }

    public function daftar_data()
    {
        if ($this->session->userdata('role') !== "2") {
            redirect(base_url("dashboard"));
        } else {
            $data['menu'] = $this->modelSetting->data_menu();
            $data['setting_perusahaan'] = $this->modelSetting->get_data_perusahaan();
            $data['no_order_po'] = $this->_generateNomor();
            $data['css'] = 'po/daftar_data/daftar_po_css';
            $this->load->view('template/template_header', $data);
            $this->load->view('template/template_menu');
            $this->load->view('po/daftar_data/daftar_po', $data);
            $this->load->view('template/template_right');
            $this->load->view('po/daftar_data/daftar_po_modal', $data);
            $this->load->view('template/template_footer');
            $this->load->view('template/template_js');
            $this->load->view('po/daftar_data/daftar_po_js');
            $this->load->view('template/template_app_js');
        }
    }


    private function _generateNomor()
    {
        $this->db->select('MAX(`id`) as id');
        $this->db->from('master_po');
        $data = $this->db->get()->row_array();
        $string = $data['id'];
        if ($string  !== null) {
            $number = substr($string, 0, 10);
            // $number = substr($string, -3);
            $number = $number + 1;
            $tgl = date('ymd');
            return $tgl . sprintf("%03d", $number);
        } else {
            $tgl = date('ymd');
            return $tgl . sprintf("%03d", 1);
        }
    }

    public function clear_keranjang_po($no_order_lama)
    {
        $this->modelPO->get_data_keranjang_clear($no_order_lama);
    }

    public function get_data_supplier()
    {
        $string = $this->input->post('query');
        $data = $this->modelPO->get_data_supplier($string);
        $output = json_encode($data);
        echo $output;
    }

    public function get_data_barang($string = null)
    {
        $string = str_replace("%20", " ", $string);
        $database = $this->modelPenjualan->get_data_barang($string);
        $data = $database->result_array();
        $output = array(
            "recordsTotal" => $this->db->count_all_results(),
            "jumlah_data"  => $database->num_rows(),
            "data" => $data
        );
        $output = json_encode($output);
        echo $output;
    }

    public function get_data_barang_versi_select2()
    {
        $string = $this->input->post('query');
        $database = $this->modelPenjualan->get_data_barang($string);
        $data = $database->result_array();
        $output = array(
            "recordsTotal" => $this->db->count_all_results(),
            "jumlah_data"  => $database->num_rows(),
            "data" => $data
        );
        $output = json_encode($output);
        echo $output;
    }

    public function push_data_barang()
    {
        $this->modelPO->push_data_barang();
    }

    function push_total_perhitungan()
    {
        $post = $this->input->post();
        $this->modelPO->push_total_perhitungan($post);
    }

    public function get_data_keranjang($no_order_po)
    {
        $database = $this->modelPO->get_data_keranjang($no_order_po);
        $data = $database->result_array();
        $output = array(
            "recordsTotal" => $this->db->count_all_results(),
            "recordsFiltered"  => $database->num_rows(),
            "data" => $data
        );
        $output = json_encode($output);
        echo $output;
    }

    public function delete_data_keranjang($id)
    {
        if (empty($id)) {
        } else {
            $this->modelPO->delete_data_keranjang($id); // delete data
        }
    }

    public function get_sum_keranjang($no_order)
    {

        $output = $this->modelPO->get_sum_keranjang($no_order);
        $output = json_encode($output);
        echo $output;
    }

    public function push_grand_total()
    {
        $post = $this->input->post();
        $this->modelPO->push_grand_total($post);
    }

    function get_total_perhitungan($no_order)
    {
        $data = $this->modelPO->get_total_perhitungan($no_order);
        $output = json_encode($data);
        echo $output;
    }

    function proses()
    {
        $post = $this->input->post();
        $this->db->select('*');
        $this->db->from('master_po');
        $this->db->where('no_order_po', $post['no_order_po']);
        $cek = $this->db->get()->num_rows();
        if ($cek > 0) {
            echo "1";
        } else {
            $this->modelPO->proses($post);
        }
    }

    function get_data_po(){
        $post = $this->input->post();
        $this->db->select('*');
        $this->db->from('master_po');
        $this->db->where('no_order_po', $post['no_order_po']);
        $data =  $this->db->get()->row_array();
        $output = json_encode($data);
        echo $output;
    }
}
